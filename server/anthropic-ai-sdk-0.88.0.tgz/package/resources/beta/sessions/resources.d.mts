import { APIResource } from "../../../core/resource.mjs";
import * as BetaAPI from "../beta.mjs";
import * as SessionsAPI from "./sessions.mjs";
import { APIPromise } from "../../../core/api-promise.mjs";
import { PageCursor, type PageCursorParams, PagePromise } from "../../../core/pagination.mjs";
import { RequestOptions } from "../../../internal/request-options.mjs";
export declare class Resources extends APIResource {
    /**
     * Get Session Resource
     *
     * @example
     * ```ts
     * const resource =
     *   await client.beta.sessions.resources.retrieve(
     *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    retrieve(resourceID: string, params: ResourceRetrieveParams, options?: RequestOptions): APIPromise<ResourceRetrieveResponse>;
    /**
     * Update Session Resource
     *
     * @example
     * ```ts
     * const resource =
     *   await client.beta.sessions.resources.update(
     *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
     *     {
     *       session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *       authorization_token: 'ghp_exampletoken',
     *     },
     *   );
     * ```
     */
    update(resourceID: string, params: ResourceUpdateParams, options?: RequestOptions): APIPromise<ResourceUpdateResponse>;
    /**
     * List Session Resources
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionResource of client.beta.sessions.resources.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(sessionID: string, params?: ResourceListParams | null | undefined, options?: RequestOptions): PagePromise<BetaManagedAgentsSessionResourcesPageCursor, BetaManagedAgentsSessionResource>;
    /**
     * Delete Session Resource
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeleteSessionResource =
     *   await client.beta.sessions.resources.delete(
     *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    delete(resourceID: string, params: ResourceDeleteParams, options?: RequestOptions): APIPromise<BetaManagedAgentsDeleteSessionResource>;
    /**
     * Add Session Resource
     *
     * @example
     * ```ts
     * const betaManagedAgentsFileResource =
     *   await client.beta.sessions.resources.add(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *     {
     *       file_id: 'file_011CNha8iCJcU1wXNR6q4V8w',
     *       type: 'file',
     *     },
     *   );
     * ```
     */
    add(sessionID: string, params: ResourceAddParams, options?: RequestOptions): APIPromise<BetaManagedAgentsFileResource>;
}
export type BetaManagedAgentsSessionResourcesPageCursor = PageCursor<BetaManagedAgentsSessionResource>;
/**
 * Confirmation of resource deletion.
 */
export interface BetaManagedAgentsDeleteSessionResource {
    id: string;
    type: 'session_resource_deleted';
}
export interface BetaManagedAgentsFileResource {
    id: string;
    /**
     * A timestamp in RFC 3339 format
     */
    created_at: string;
    file_id: string;
    mount_path: string;
    type: 'file';
    /**
     * A timestamp in RFC 3339 format
     */
    updated_at: string;
}
export interface BetaManagedAgentsGitHubRepositoryResource {
    id: string;
    /**
     * A timestamp in RFC 3339 format
     */
    created_at: string;
    mount_path: string;
    type: 'github_repository';
    /**
     * A timestamp in RFC 3339 format
     */
    updated_at: string;
    url: string;
    checkout?: SessionsAPI.BetaManagedAgentsBranchCheckout | SessionsAPI.BetaManagedAgentsCommitCheckout | null;
}
export type BetaManagedAgentsSessionResource = BetaManagedAgentsGitHubRepositoryResource | BetaManagedAgentsFileResource;
/**
 * The requested session resource.
 */
export type ResourceRetrieveResponse = BetaManagedAgentsGitHubRepositoryResource | BetaManagedAgentsFileResource;
/**
 * The updated session resource.
 */
export type ResourceUpdateResponse = BetaManagedAgentsGitHubRepositoryResource | BetaManagedAgentsFileResource;
export interface ResourceRetrieveParams {
    /**
     * Path param: Path parameter session_id
     */
    session_id: string;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface ResourceUpdateParams {
    /**
     * Path param: Path parameter session_id
     */
    session_id: string;
    /**
     * Body param: New authorization token for the resource. Currently only
     * `github_repository` resources support token rotation.
     */
    authorization_token: string;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface ResourceListParams extends PageCursorParams {
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface ResourceDeleteParams {
    /**
     * Path param: Path parameter session_id
     */
    session_id: string;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface ResourceAddParams {
    /**
     * Body param: ID of a previously uploaded file.
     */
    file_id: string;
    /**
     * Body param
     */
    type: 'file';
    /**
     * Body param: Mount path in the container. Defaults to
     * `/mnt/session/uploads/<file_id>`.
     */
    mount_path?: string | null;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export declare namespace Resources {
    export { type BetaManagedAgentsDeleteSessionResource as BetaManagedAgentsDeleteSessionResource, type BetaManagedAgentsFileResource as BetaManagedAgentsFileResource, type BetaManagedAgentsGitHubRepositoryResource as BetaManagedAgentsGitHubRepositoryResource, type BetaManagedAgentsSessionResource as BetaManagedAgentsSessionResource, type ResourceRetrieveResponse as ResourceRetrieveResponse, type ResourceUpdateResponse as ResourceUpdateResponse, type BetaManagedAgentsSessionResourcesPageCursor as BetaManagedAgentsSessionResourcesPageCursor, type ResourceRetrieveParams as ResourceRetrieveParams, type ResourceUpdateParams as ResourceUpdateParams, type ResourceListParams as ResourceListParams, type ResourceDeleteParams as ResourceDeleteParams, type ResourceAddParams as ResourceAddParams, };
}
//# sourceMappingURL=resources.d.mts.map