import { APIResource } from "../../../core/resource.js";
import * as BetaAPI from "../beta.js";
import { APIPromise } from "../../../core/api-promise.js";
import { PageCursor, type PageCursorParams, PagePromise } from "../../../core/pagination.js";
import { RequestOptions } from "../../../internal/request-options.js";
export declare class Credentials extends APIResource {
    /**
     * Create Credential
     *
     * @example
     * ```ts
     * const betaManagedAgentsCredential =
     *   await client.beta.vaults.credentials.create(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *     {
     *       auth: {
     *         token: 'bearer_exampletoken',
     *         mcp_server_url:
     *           'https://example-server.modelcontextprotocol.io/sse',
     *         type: 'static_bearer',
     *       },
     *     },
     *   );
     * ```
     */
    create(vaultID: string, params: CredentialCreateParams, options?: RequestOptions): APIPromise<BetaManagedAgentsCredential>;
    /**
     * Get Credential
     *
     * @example
     * ```ts
     * const betaManagedAgentsCredential =
     *   await client.beta.vaults.credentials.retrieve(
     *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
     *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
     *   );
     * ```
     */
    retrieve(credentialID: string, params: CredentialRetrieveParams, options?: RequestOptions): APIPromise<BetaManagedAgentsCredential>;
    /**
     * Update Credential
     *
     * @example
     * ```ts
     * const betaManagedAgentsCredential =
     *   await client.beta.vaults.credentials.update(
     *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
     *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
     *   );
     * ```
     */
    update(credentialID: string, params: CredentialUpdateParams, options?: RequestOptions): APIPromise<BetaManagedAgentsCredential>;
    /**
     * List Credentials
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsCredential of client.beta.vaults.credentials.list(
     *   'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(vaultID: string, params?: CredentialListParams | null | undefined, options?: RequestOptions): PagePromise<BetaManagedAgentsCredentialsPageCursor, BetaManagedAgentsCredential>;
    /**
     * Delete Credential
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedCredential =
     *   await client.beta.vaults.credentials.delete(
     *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
     *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
     *   );
     * ```
     */
    delete(credentialID: string, params: CredentialDeleteParams, options?: RequestOptions): APIPromise<BetaManagedAgentsDeletedCredential>;
    /**
     * Archive Credential
     *
     * @example
     * ```ts
     * const betaManagedAgentsCredential =
     *   await client.beta.vaults.credentials.archive(
     *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
     *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
     *   );
     * ```
     */
    archive(credentialID: string, params: CredentialArchiveParams, options?: RequestOptions): APIPromise<BetaManagedAgentsCredential>;
}
export type BetaManagedAgentsCredentialsPageCursor = PageCursor<BetaManagedAgentsCredential>;
/**
 * A credential stored in a vault. Sensitive fields are never returned in
 * responses.
 */
export interface BetaManagedAgentsCredential {
    /**
     * Unique identifier for the credential.
     */
    id: string;
    /**
     * A timestamp in RFC 3339 format
     */
    archived_at: string | null;
    /**
     * Authentication details for a credential.
     */
    auth: BetaManagedAgentsMCPOAuthAuthResponse | BetaManagedAgentsStaticBearerAuthResponse;
    /**
     * A timestamp in RFC 3339 format
     */
    created_at: string;
    /**
     * Arbitrary key-value metadata attached to the credential.
     */
    metadata: {
        [key: string]: string;
    };
    type: 'vault_credential';
    /**
     * A timestamp in RFC 3339 format
     */
    updated_at: string;
    /**
     * Identifier of the vault this credential belongs to.
     */
    vault_id: string;
    /**
     * Human-readable name for the credential.
     */
    display_name?: string | null;
}
/**
 * Confirmation of a deleted credential.
 */
export interface BetaManagedAgentsDeletedCredential {
    /**
     * Unique identifier of the deleted credential.
     */
    id: string;
    type: 'vault_credential_deleted';
}
/**
 * OAuth credential details for an MCP server.
 */
export interface BetaManagedAgentsMCPOAuthAuthResponse {
    /**
     * URL of the MCP server this credential authenticates against.
     */
    mcp_server_url: string;
    type: 'mcp_oauth';
    /**
     * A timestamp in RFC 3339 format
     */
    expires_at?: string | null;
    /**
     * OAuth refresh token configuration returned in credential responses.
     */
    refresh?: BetaManagedAgentsMCPOAuthRefreshResponse | null;
}
/**
 * Parameters for creating an MCP OAuth credential.
 */
export interface BetaManagedAgentsMCPOAuthCreateParams {
    /**
     * OAuth access token.
     */
    access_token: string;
    /**
     * URL of the MCP server this credential authenticates against.
     */
    mcp_server_url: string;
    type: 'mcp_oauth';
    /**
     * A timestamp in RFC 3339 format
     */
    expires_at?: string | null;
    /**
     * OAuth refresh token parameters for creating a credential with refresh support.
     */
    refresh?: BetaManagedAgentsMCPOAuthRefreshParams | null;
}
/**
 * OAuth refresh token parameters for creating a credential with refresh support.
 */
export interface BetaManagedAgentsMCPOAuthRefreshParams {
    /**
     * OAuth client ID.
     */
    client_id: string;
    /**
     * OAuth refresh token.
     */
    refresh_token: string;
    /**
     * Token endpoint URL used to refresh the access token.
     */
    token_endpoint: string;
    /**
     * Token endpoint requires no client authentication.
     */
    token_endpoint_auth: BetaManagedAgentsTokenEndpointAuthNoneParam | BetaManagedAgentsTokenEndpointAuthBasicParam | BetaManagedAgentsTokenEndpointAuthPostParam;
    /**
     * OAuth resource indicator.
     */
    resource?: string | null;
    /**
     * OAuth scope for the refresh request.
     */
    scope?: string | null;
}
/**
 * OAuth refresh token configuration returned in credential responses.
 */
export interface BetaManagedAgentsMCPOAuthRefreshResponse {
    /**
     * OAuth client ID.
     */
    client_id: string;
    /**
     * Token endpoint URL used to refresh the access token.
     */
    token_endpoint: string;
    /**
     * Token endpoint requires no client authentication.
     */
    token_endpoint_auth: BetaManagedAgentsTokenEndpointAuthNoneResponse | BetaManagedAgentsTokenEndpointAuthBasicResponse | BetaManagedAgentsTokenEndpointAuthPostResponse;
    /**
     * OAuth resource indicator.
     */
    resource?: string | null;
    /**
     * OAuth scope for the refresh request.
     */
    scope?: string | null;
}
/**
 * Parameters for updating OAuth refresh token configuration.
 */
export interface BetaManagedAgentsMCPOAuthRefreshUpdateParams {
    /**
     * Updated OAuth refresh token.
     */
    refresh_token?: string | null;
    /**
     * Updated OAuth scope for the refresh request.
     */
    scope?: string | null;
    /**
     * Updated HTTP Basic authentication parameters for the token endpoint.
     */
    token_endpoint_auth?: BetaManagedAgentsTokenEndpointAuthBasicUpdateParam | BetaManagedAgentsTokenEndpointAuthPostUpdateParam;
}
/**
 * Parameters for updating an MCP OAuth credential. The `mcp_server_url` is
 * immutable.
 */
export interface BetaManagedAgentsMCPOAuthUpdateParams {
    type: 'mcp_oauth';
    /**
     * Updated OAuth access token.
     */
    access_token?: string | null;
    /**
     * A timestamp in RFC 3339 format
     */
    expires_at?: string | null;
    /**
     * Parameters for updating OAuth refresh token configuration.
     */
    refresh?: BetaManagedAgentsMCPOAuthRefreshUpdateParams | null;
}
/**
 * Static bearer token credential details for an MCP server.
 */
export interface BetaManagedAgentsStaticBearerAuthResponse {
    /**
     * URL of the MCP server this credential authenticates against.
     */
    mcp_server_url: string;
    type: 'static_bearer';
}
/**
 * Parameters for creating a static bearer token credential.
 */
export interface BetaManagedAgentsStaticBearerCreateParams {
    /**
     * Static bearer token value.
     */
    token: string;
    /**
     * URL of the MCP server this credential authenticates against.
     */
    mcp_server_url: string;
    type: 'static_bearer';
}
/**
 * Parameters for updating a static bearer token credential. The `mcp_server_url`
 * is immutable.
 */
export interface BetaManagedAgentsStaticBearerUpdateParams {
    type: 'static_bearer';
    /**
     * Updated static bearer token value.
     */
    token?: string | null;
}
/**
 * Token endpoint uses HTTP Basic authentication with client credentials.
 */
export interface BetaManagedAgentsTokenEndpointAuthBasicParam {
    /**
     * OAuth client secret.
     */
    client_secret: string;
    type: 'client_secret_basic';
}
/**
 * Token endpoint uses HTTP Basic authentication with client credentials.
 */
export interface BetaManagedAgentsTokenEndpointAuthBasicResponse {
    type: 'client_secret_basic';
}
/**
 * Updated HTTP Basic authentication parameters for the token endpoint.
 */
export interface BetaManagedAgentsTokenEndpointAuthBasicUpdateParam {
    type: 'client_secret_basic';
    /**
     * Updated OAuth client secret.
     */
    client_secret?: string | null;
}
/**
 * Token endpoint requires no client authentication.
 */
export interface BetaManagedAgentsTokenEndpointAuthNoneParam {
    type: 'none';
}
/**
 * Token endpoint requires no client authentication.
 */
export interface BetaManagedAgentsTokenEndpointAuthNoneResponse {
    type: 'none';
}
/**
 * Token endpoint uses POST body authentication with client credentials.
 */
export interface BetaManagedAgentsTokenEndpointAuthPostParam {
    /**
     * OAuth client secret.
     */
    client_secret: string;
    type: 'client_secret_post';
}
/**
 * Token endpoint uses POST body authentication with client credentials.
 */
export interface BetaManagedAgentsTokenEndpointAuthPostResponse {
    type: 'client_secret_post';
}
/**
 * Updated POST body authentication parameters for the token endpoint.
 */
export interface BetaManagedAgentsTokenEndpointAuthPostUpdateParam {
    type: 'client_secret_post';
    /**
     * Updated OAuth client secret.
     */
    client_secret?: string | null;
}
export interface CredentialCreateParams {
    /**
     * Body param: Authentication details for creating a credential.
     */
    auth: BetaManagedAgentsMCPOAuthCreateParams | BetaManagedAgentsStaticBearerCreateParams;
    /**
     * Body param: Human-readable name for the credential. Up to 255 characters.
     */
    display_name?: string | null;
    /**
     * Body param: Arbitrary key-value metadata to attach to the credential. Maximum 16
     * pairs, keys up to 64 chars, values up to 512 chars.
     */
    metadata?: {
        [key: string]: string;
    };
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface CredentialRetrieveParams {
    /**
     * Path param: Path parameter vault_id
     */
    vault_id: string;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface CredentialUpdateParams {
    /**
     * Path param: Path parameter vault_id
     */
    vault_id: string;
    /**
     * Body param: Updated authentication details for a credential.
     */
    auth?: BetaManagedAgentsMCPOAuthUpdateParams | BetaManagedAgentsStaticBearerUpdateParams;
    /**
     * Body param: Updated human-readable name for the credential. 1-255 characters.
     */
    display_name?: string | null;
    /**
     * Body param: Metadata patch. Set a key to a string to upsert it, or to null to
     * delete it. Omitted keys are preserved.
     */
    metadata?: {
        [key: string]: string | null;
    } | null;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface CredentialListParams extends PageCursorParams {
    /**
     * Query param: Whether to include archived credentials in the results.
     */
    include_archived?: boolean;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface CredentialDeleteParams {
    /**
     * Path param: Path parameter vault_id
     */
    vault_id: string;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export interface CredentialArchiveParams {
    /**
     * Path param: Path parameter vault_id
     */
    vault_id: string;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
}
export declare namespace Credentials {
    export { type BetaManagedAgentsCredential as BetaManagedAgentsCredential, type BetaManagedAgentsDeletedCredential as BetaManagedAgentsDeletedCredential, type BetaManagedAgentsMCPOAuthAuthResponse as BetaManagedAgentsMCPOAuthAuthResponse, type BetaManagedAgentsMCPOAuthCreateParams as BetaManagedAgentsMCPOAuthCreateParams, type BetaManagedAgentsMCPOAuthRefreshParams as BetaManagedAgentsMCPOAuthRefreshParams, type BetaManagedAgentsMCPOAuthRefreshResponse as BetaManagedAgentsMCPOAuthRefreshResponse, type BetaManagedAgentsMCPOAuthRefreshUpdateParams as BetaManagedAgentsMCPOAuthRefreshUpdateParams, type BetaManagedAgentsMCPOAuthUpdateParams as BetaManagedAgentsMCPOAuthUpdateParams, type BetaManagedAgentsStaticBearerAuthResponse as BetaManagedAgentsStaticBearerAuthResponse, type BetaManagedAgentsStaticBearerCreateParams as BetaManagedAgentsStaticBearerCreateParams, type BetaManagedAgentsStaticBearerUpdateParams as BetaManagedAgentsStaticBearerUpdateParams, type BetaManagedAgentsTokenEndpointAuthBasicParam as BetaManagedAgentsTokenEndpointAuthBasicParam, type BetaManagedAgentsTokenEndpointAuthBasicResponse as BetaManagedAgentsTokenEndpointAuthBasicResponse, type BetaManagedAgentsTokenEndpointAuthBasicUpdateParam as BetaManagedAgentsTokenEndpointAuthBasicUpdateParam, type BetaManagedAgentsTokenEndpointAuthNoneParam as BetaManagedAgentsTokenEndpointAuthNoneParam, type BetaManagedAgentsTokenEndpointAuthNoneResponse as BetaManagedAgentsTokenEndpointAuthNoneResponse, type BetaManagedAgentsTokenEndpointAuthPostParam as BetaManagedAgentsTokenEndpointAuthPostParam, type BetaManagedAgentsTokenEndpointAuthPostResponse as BetaManagedAgentsTokenEndpointAuthPostResponse, type BetaManagedAgentsTokenEndpointAuthPostUpdateParam as BetaManagedAgentsTokenEndpointAuthPostUpdateParam, type BetaManagedAgentsCredentialsPageCursor as BetaManagedAgentsCredentialsPageCursor, type CredentialCreateParams as CredentialCreateParams, type CredentialRetrieveParams as CredentialRetrieveParams, type CredentialUpdateParams as CredentialUpdateParams, type CredentialListParams as CredentialListParams, type CredentialDeleteParams as CredentialDeleteParams, type CredentialArchiveParams as CredentialArchiveParams, };
}
//# sourceMappingURL=credentials.d.ts.map