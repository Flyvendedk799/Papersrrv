import { APIPromise } from "../../core/api-promise.js";
import { APIResource } from "../../core/resource.js";
import { Stream } from "../../core/streaming.js";
import { RequestOptions } from "../../internal/request-options.js";
import { MessageStream } from "../../lib/MessageStream.js";
import { type ExtractParsedContentFromParams, type ParseableMessageCreateParams, type ParsedMessage } from "../../lib/parser.js";
import * as BatchesAPI from "./batches.js";
import { BatchCreateParams, BatchListParams, Batches, DeletedMessageBatch, MessageBatch, MessageBatchCanceledResult, MessageBatchErroredResult, MessageBatchExpiredResult, MessageBatchIndividualResponse, MessageBatchRequestCounts, MessageBatchResult, MessageBatchSucceededResult, MessageBatchesPage } from "./batches.js";
import * as MessagesAPI from "./messages.js";
export declare class Messages extends APIResource {
    batches: BatchesAPI.Batches;
    /**
     * Send a structured list of input messages with text and/or image content, and the
     * model will generate the next message in the conversation.
     *
     * The Messages API can be used for either single queries or stateless multi-turn
     * conversations.
     *
     * Learn more about the Messages API in our
     * [user guide](https://docs.claude.com/en/docs/initial-setup)
     *
     * @example
     * ```ts
     * const message = await client.messages.create({
     *   max_tokens: 1024,
     *   messages: [{ content: 'Hello, world', role: 'user' }],
     *   model: 'claude-opus-4-6',
     * });
     * ```
     */
    create(body: MessageCreateParamsNonStreaming, options?: RequestOptions): APIPromise<Message>;
    create(body: MessageCreateParamsStreaming, options?: RequestOptions): APIPromise<Stream<RawMessageStreamEvent>>;
    create(body: MessageCreateParamsBase, options?: RequestOptions): APIPromise<Stream<RawMessageStreamEvent> | Message>;
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_config.format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.messages.parse({
     *   model: 'claude-sonnet-4-5-20250929',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse<Params extends MessageCreateParamsNonStreaming>(params: Params, options?: RequestOptions): APIPromise<ParsedMessage<ExtractParsedContentFromParams<Params>>>;
    /**
     * Create a Message stream.
     *
     * If `output_config.format` is provided with a parseable format (like `zodOutputFormat()`),
     * the final message will include a `parsed_output` property with the parsed content.
     *
     * @example
     * ```ts
     * const stream = client.messages.stream({
     *   model: 'claude-sonnet-4-5-20250929',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * const message = await stream.finalMessage();
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    stream<Params extends MessageStreamParams>(body: Params, options?: RequestOptions): MessageStream<ExtractParsedContentFromParams<Params>>;
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const messageTokensCount =
     *   await client.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-4-6',
     *   });
     * ```
     */
    countTokens(body: MessageCountTokensParams, options?: RequestOptions): APIPromise<MessageTokensCount>;
}
export interface Base64ImageSource {
    data: string;
    media_type: 'image/jpeg' | 'image/png' | 'image/gif' | 'image/webp';
    type: 'base64';
}
export interface Base64PDFSource {
    data: string;
    media_type: 'application/pdf';
    type: 'base64';
}
export interface BashCodeExecutionOutputBlock {
    file_id: string;
    type: 'bash_code_execution_output';
}
export interface BashCodeExecutionOutputBlockParam {
    file_id: string;
    type: 'bash_code_execution_output';
}
export interface BashCodeExecutionResultBlock {
    content: Array<BashCodeExecutionOutputBlock>;
    return_code: number;
    stderr: string;
    stdout: string;
    type: 'bash_code_execution_result';
}
export interface BashCodeExecutionResultBlockParam {
    content: Array<BashCodeExecutionOutputBlockParam>;
    return_code: number;
    stderr: string;
    stdout: string;
    type: 'bash_code_execution_result';
}
export interface BashCodeExecutionToolResultBlock {
    content: BashCodeExecutionToolResultError | BashCodeExecutionResultBlock;
    tool_use_id: string;
    type: 'bash_code_execution_tool_result';
}
export interface BashCodeExecutionToolResultBlockParam {
    content: BashCodeExecutionToolResultErrorParam | BashCodeExecutionResultBlockParam;
    tool_use_id: string;
    type: 'bash_code_execution_tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
export interface BashCodeExecutionToolResultError {
    error_code: BashCodeExecutionToolResultErrorCode;
    type: 'bash_code_execution_tool_result_error';
}
export type BashCodeExecutionToolResultErrorCode = 'invalid_tool_input' | 'unavailable' | 'too_many_requests' | 'execution_time_exceeded' | 'output_file_too_large';
export interface BashCodeExecutionToolResultErrorParam {
    error_code: BashCodeExecutionToolResultErrorCode;
    type: 'bash_code_execution_tool_result_error';
}
export interface CacheControlEphemeral {
    type: 'ephemeral';
    /**
     * The time-to-live for the cache control breakpoint.
     *
     * This may be one the following values:
     *
     * - `5m`: 5 minutes
     * - `1h`: 1 hour
     *
     * Defaults to `5m`.
     */
    ttl?: '5m' | '1h';
}
export interface CacheCreation {
    /**
     * The number of input tokens used to create the 1 hour cache entry.
     */
    ephemeral_1h_input_tokens: number;
    /**
     * The number of input tokens used to create the 5 minute cache entry.
     */
    ephemeral_5m_input_tokens: number;
}
export interface CitationCharLocation {
    cited_text: string;
    document_index: number;
    document_title: string | null;
    end_char_index: number;
    file_id: string | null;
    start_char_index: number;
    type: 'char_location';
}
export interface CitationCharLocationParam {
    cited_text: string;
    document_index: number;
    document_title: string | null;
    end_char_index: number;
    start_char_index: number;
    type: 'char_location';
}
export interface CitationContentBlockLocation {
    cited_text: string;
    document_index: number;
    document_title: string | null;
    end_block_index: number;
    file_id: string | null;
    start_block_index: number;
    type: 'content_block_location';
}
export interface CitationContentBlockLocationParam {
    cited_text: string;
    document_index: number;
    document_title: string | null;
    end_block_index: number;
    start_block_index: number;
    type: 'content_block_location';
}
export interface CitationPageLocation {
    cited_text: string;
    document_index: number;
    document_title: string | null;
    end_page_number: number;
    file_id: string | null;
    start_page_number: number;
    type: 'page_location';
}
export interface CitationPageLocationParam {
    cited_text: string;
    document_index: number;
    document_title: string | null;
    end_page_number: number;
    start_page_number: number;
    type: 'page_location';
}
export interface CitationSearchResultLocationParam {
    cited_text: string;
    end_block_index: number;
    search_result_index: number;
    source: string;
    start_block_index: number;
    title: string | null;
    type: 'search_result_location';
}
export interface CitationWebSearchResultLocationParam {
    cited_text: string;
    encrypted_index: string;
    title: string | null;
    type: 'web_search_result_location';
    url: string;
}
export interface CitationsConfig {
    enabled: boolean;
}
export interface CitationsConfigParam {
    enabled?: boolean;
}
export interface CitationsDelta {
    citation: CitationCharLocation | CitationPageLocation | CitationContentBlockLocation | CitationsWebSearchResultLocation | CitationsSearchResultLocation;
    type: 'citations_delta';
}
export interface CitationsSearchResultLocation {
    cited_text: string;
    end_block_index: number;
    search_result_index: number;
    source: string;
    start_block_index: number;
    title: string | null;
    type: 'search_result_location';
}
export interface CitationsWebSearchResultLocation {
    cited_text: string;
    encrypted_index: string;
    title: string | null;
    type: 'web_search_result_location';
    url: string;
}
export interface CodeExecutionOutputBlock {
    file_id: string;
    type: 'code_execution_output';
}
export interface CodeExecutionOutputBlockParam {
    file_id: string;
    type: 'code_execution_output';
}
export interface CodeExecutionResultBlock {
    content: Array<CodeExecutionOutputBlock>;
    return_code: number;
    stderr: string;
    stdout: string;
    type: 'code_execution_result';
}
export interface CodeExecutionResultBlockParam {
    content: Array<CodeExecutionOutputBlockParam>;
    return_code: number;
    stderr: string;
    stdout: string;
    type: 'code_execution_result';
}
export interface CodeExecutionTool20250522 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'code_execution';
    type: 'code_execution_20250522';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface CodeExecutionTool20250825 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'code_execution';
    type: 'code_execution_20250825';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
/**
 * Code execution tool with REPL state persistence (daemon mode + gVisor
 * checkpoint).
 */
export interface CodeExecutionTool20260120 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'code_execution';
    type: 'code_execution_20260120';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface CodeExecutionToolResultBlock {
    /**
     * Code execution result with encrypted stdout for PFC + web_search results.
     */
    content: CodeExecutionToolResultBlockContent;
    tool_use_id: string;
    type: 'code_execution_tool_result';
}
/**
 * Code execution result with encrypted stdout for PFC + web_search results.
 */
export type CodeExecutionToolResultBlockContent = CodeExecutionToolResultError | CodeExecutionResultBlock | EncryptedCodeExecutionResultBlock;
export interface CodeExecutionToolResultBlockParam {
    /**
     * Code execution result with encrypted stdout for PFC + web_search results.
     */
    content: CodeExecutionToolResultBlockParamContent;
    tool_use_id: string;
    type: 'code_execution_tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
/**
 * Code execution result with encrypted stdout for PFC + web_search results.
 */
export type CodeExecutionToolResultBlockParamContent = CodeExecutionToolResultErrorParam | CodeExecutionResultBlockParam | EncryptedCodeExecutionResultBlockParam;
export interface CodeExecutionToolResultError {
    error_code: CodeExecutionToolResultErrorCode;
    type: 'code_execution_tool_result_error';
}
export type CodeExecutionToolResultErrorCode = 'invalid_tool_input' | 'unavailable' | 'too_many_requests' | 'execution_time_exceeded';
export interface CodeExecutionToolResultErrorParam {
    error_code: CodeExecutionToolResultErrorCode;
    type: 'code_execution_tool_result_error';
}
/**
 * Information about the container used in the request (for the code execution
 * tool)
 */
export interface Container {
    /**
     * Identifier for the container used in this request
     */
    id: string;
    /**
     * The time at which the container will expire.
     */
    expires_at: string;
}
/**
 * Response model for a file uploaded to the container.
 */
export interface ContainerUploadBlock {
    file_id: string;
    type: 'container_upload';
}
/**
 * A content block that represents a file to be uploaded to the container Files
 * uploaded via this block will be available in the container's input directory.
 */
export interface ContainerUploadBlockParam {
    file_id: string;
    type: 'container_upload';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
/**
 * Response model for a file uploaded to the container.
 */
export type ContentBlock = TextBlock | ThinkingBlock | RedactedThinkingBlock | ToolUseBlock | ServerToolUseBlock | WebSearchToolResultBlock | WebFetchToolResultBlock | CodeExecutionToolResultBlock | BashCodeExecutionToolResultBlock | TextEditorCodeExecutionToolResultBlock | ToolSearchToolResultBlock | ContainerUploadBlock;
/**
 * Regular text content.
 */
export type ContentBlockParam = TextBlockParam | ImageBlockParam | DocumentBlockParam | SearchResultBlockParam | ThinkingBlockParam | RedactedThinkingBlockParam | ToolUseBlockParam | ToolResultBlockParam | ServerToolUseBlockParam | WebSearchToolResultBlockParam | WebFetchToolResultBlockParam | CodeExecutionToolResultBlockParam | BashCodeExecutionToolResultBlockParam | TextEditorCodeExecutionToolResultBlockParam | ToolSearchToolResultBlockParam | ContainerUploadBlockParam;
export interface ContentBlockSource {
    content: string | Array<ContentBlockSourceContent>;
    type: 'content';
}
export type ContentBlockSourceContent = TextBlockParam | ImageBlockParam;
/**
 * Tool invocation directly from the model.
 */
export interface DirectCaller {
    type: 'direct';
}
export interface DocumentBlock {
    /**
     * Citation configuration for the document
     */
    citations: CitationsConfig | null;
    source: Base64PDFSource | PlainTextSource;
    /**
     * The title of the document
     */
    title: string | null;
    type: 'document';
}
export interface DocumentBlockParam {
    source: Base64PDFSource | PlainTextSource | ContentBlockSource | URLPDFSource;
    type: 'document';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    citations?: CitationsConfigParam | null;
    context?: string | null;
    title?: string | null;
}
/**
 * Code execution result with encrypted stdout for PFC + web_search results.
 */
export interface EncryptedCodeExecutionResultBlock {
    content: Array<CodeExecutionOutputBlock>;
    encrypted_stdout: string;
    return_code: number;
    stderr: string;
    type: 'encrypted_code_execution_result';
}
/**
 * Code execution result with encrypted stdout for PFC + web_search results.
 */
export interface EncryptedCodeExecutionResultBlockParam {
    content: Array<CodeExecutionOutputBlockParam>;
    encrypted_stdout: string;
    return_code: number;
    stderr: string;
    type: 'encrypted_code_execution_result';
}
export interface ImageBlockParam {
    source: Base64ImageSource | URLImageSource;
    type: 'image';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
export interface InputJSONDelta {
    partial_json: string;
    type: 'input_json_delta';
}
export interface JSONOutputFormat {
    /**
     * The JSON schema of the format
     */
    schema: {
        [key: string]: unknown;
    };
    type: 'json_schema';
}
export interface MemoryTool20250818 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'memory';
    type: 'memory_20250818';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    input_examples?: Array<{
        [key: string]: unknown;
    }>;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface Message {
    /**
     * Unique object identifier.
     *
     * The format and length of IDs may change over time.
     */
    id: string;
    /**
     * Information about the container used in the request (for the code execution
     * tool)
     */
    container: Container | null;
    /**
     * Content generated by the model.
     *
     * This is an array of content blocks, each of which has a `type` that determines
     * its shape.
     *
     * Example:
     *
     * ```json
     * [{ "type": "text", "text": "Hi, I'm Claude." }]
     * ```
     *
     * If the request input `messages` ended with an `assistant` turn, then the
     * response `content` will continue directly from that last turn. You can use this
     * to constrain the model's output.
     *
     * For example, if the input `messages` were:
     *
     * ```json
     * [
     *   {
     *     "role": "user",
     *     "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
     *   },
     *   { "role": "assistant", "content": "The best answer is (" }
     * ]
     * ```
     *
     * Then the response `content` might be:
     *
     * ```json
     * [{ "type": "text", "text": "B)" }]
     * ```
     */
    content: Array<ContentBlock>;
    /**
     * The model that will complete your prompt.\n\nSee
     * [models](https://docs.anthropic.com/en/docs/models-overview) for additional
     * details and options.
     */
    model: Model;
    /**
     * Conversational role of the generated message.
     *
     * This will always be `"assistant"`.
     */
    role: 'assistant';
    /**
     * Structured information about a refusal.
     */
    stop_details: RefusalStopDetails | null;
    /**
     * The reason that we stopped.
     *
     * This may be one the following values:
     *
     * - `"end_turn"`: the model reached a natural stopping point
     * - `"max_tokens"`: we exceeded the requested `max_tokens` or the model's maximum
     * - `"stop_sequence"`: one of your provided custom `stop_sequences` was generated
     * - `"tool_use"`: the model invoked one or more tools
     * - `"pause_turn"`: we paused a long-running turn. You may provide the response
     *   back as-is in a subsequent request to let the model continue.
     * - `"refusal"`: when streaming classifiers intervene to handle potential policy
     *   violations
     *
     * In non-streaming mode this value is always non-null. In streaming mode, it is
     * null in the `message_start` event and non-null otherwise.
     */
    stop_reason: StopReason | null;
    /**
     * Which custom stop sequence was generated, if any.
     *
     * This value will be a non-null string if one of your custom stop sequences was
     * generated.
     */
    stop_sequence: string | null;
    /**
     * Object type.
     *
     * For Messages, this is always `"message"`.
     */
    type: 'message';
    /**
     * Billing and rate-limit usage.
     *
     * Anthropic's API bills and rate-limits by token counts, as tokens represent the
     * underlying cost to our systems.
     *
     * Under the hood, the API transforms requests into a format suitable for the
     * model. The model's output then goes through a parsing stage before becoming an
     * API response. As a result, the token counts in `usage` will not match one-to-one
     * with the exact visible content of an API request or response.
     *
     * For example, `output_tokens` will be non-zero, even for an empty string response
     * from Claude.
     *
     * Total input tokens in a request is the summation of `input_tokens`,
     * `cache_creation_input_tokens`, and `cache_read_input_tokens`.
     */
    usage: Usage;
}
/**
 * Code execution tool with REPL state persistence (daemon mode + gVisor
 * checkpoint).
 */
export type MessageCountTokensTool = Tool | ToolBash20250124 | CodeExecutionTool20250522 | CodeExecutionTool20250825 | CodeExecutionTool20260120 | MemoryTool20250818 | ToolTextEditor20250124 | ToolTextEditor20250429 | ToolTextEditor20250728 | WebSearchTool20250305 | WebFetchTool20250910 | WebSearchTool20260209 | WebFetchTool20260209 | WebFetchTool20260309 | ToolSearchToolBm25_20251119 | ToolSearchToolRegex20251119;
export interface MessageDeltaUsage {
    /**
     * The cumulative number of input tokens used to create the cache entry.
     */
    cache_creation_input_tokens: number | null;
    /**
     * The cumulative number of input tokens read from the cache.
     */
    cache_read_input_tokens: number | null;
    /**
     * The cumulative number of input tokens which were used.
     */
    input_tokens: number | null;
    /**
     * The cumulative number of output tokens which were used.
     */
    output_tokens: number;
    /**
     * The number of server tool requests.
     */
    server_tool_use: ServerToolUsage | null;
}
export interface MessageParam {
    content: string | Array<ContentBlockParam>;
    role: 'user' | 'assistant';
}
export interface MessageTokensCount {
    /**
     * The total number of tokens across the provided list of messages, system prompt,
     * and tools.
     */
    input_tokens: number;
}
export interface Metadata {
    /**
     * An external identifier for the user who is associated with the request.
     *
     * This should be a uuid, hash value, or other opaque identifier. Anthropic may use
     * this id to help detect abuse. Do not include any identifying information such as
     * name, email address, or phone number.
     */
    user_id?: string | null;
}
/**
 * The model that will complete your prompt.\n\nSee
 * [models](https://docs.anthropic.com/en/docs/models-overview) for additional
 * details and options.
 */
export type Model = 'claude-mythos-preview' | 'claude-opus-4-6' | 'claude-sonnet-4-6' | 'claude-haiku-4-5' | 'claude-haiku-4-5-20251001' | 'claude-opus-4-5' | 'claude-opus-4-5-20251101' | 'claude-sonnet-4-5' | 'claude-sonnet-4-5-20250929' | 'claude-opus-4-1' | 'claude-opus-4-1-20250805' | 'claude-opus-4-0' | 'claude-opus-4-20250514' | 'claude-sonnet-4-0' | 'claude-sonnet-4-20250514' | 'claude-3-haiku-20240307' | (string & {});
export interface OutputConfig {
    /**
     * All possible effort levels.
     */
    effort?: 'low' | 'medium' | 'high' | 'max' | null;
    /**
     * A schema to specify Claude's output format in responses. See
     * [structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs)
     */
    format?: JSONOutputFormat | null;
}
export interface PlainTextSource {
    data: string;
    media_type: 'text/plain';
    type: 'text';
}
export type RawContentBlockDelta = TextDelta | InputJSONDelta | CitationsDelta | ThinkingDelta | SignatureDelta;
export interface RawContentBlockDeltaEvent {
    delta: RawContentBlockDelta;
    index: number;
    type: 'content_block_delta';
}
export interface RawContentBlockStartEvent {
    /**
     * Response model for a file uploaded to the container.
     */
    content_block: TextBlock | ThinkingBlock | RedactedThinkingBlock | ToolUseBlock | ServerToolUseBlock | WebSearchToolResultBlock | WebFetchToolResultBlock | CodeExecutionToolResultBlock | BashCodeExecutionToolResultBlock | TextEditorCodeExecutionToolResultBlock | ToolSearchToolResultBlock | ContainerUploadBlock;
    index: number;
    type: 'content_block_start';
}
export interface RawContentBlockStopEvent {
    index: number;
    type: 'content_block_stop';
}
export interface RawMessageDeltaEvent {
    delta: RawMessageDeltaEvent.Delta;
    type: 'message_delta';
    /**
     * Billing and rate-limit usage.
     *
     * Anthropic's API bills and rate-limits by token counts, as tokens represent the
     * underlying cost to our systems.
     *
     * Under the hood, the API transforms requests into a format suitable for the
     * model. The model's output then goes through a parsing stage before becoming an
     * API response. As a result, the token counts in `usage` will not match one-to-one
     * with the exact visible content of an API request or response.
     *
     * For example, `output_tokens` will be non-zero, even for an empty string response
     * from Claude.
     *
     * Total input tokens in a request is the summation of `input_tokens`,
     * `cache_creation_input_tokens`, and `cache_read_input_tokens`.
     */
    usage: MessageDeltaUsage;
}
export declare namespace RawMessageDeltaEvent {
    interface Delta {
        /**
         * Information about the container used in the request (for the code execution
         * tool)
         */
        container: MessagesAPI.Container | null;
        /**
         * Structured information about a refusal.
         */
        stop_details: MessagesAPI.RefusalStopDetails | null;
        stop_reason: MessagesAPI.StopReason | null;
        stop_sequence: string | null;
    }
}
export interface RawMessageStartEvent {
    message: Message;
    type: 'message_start';
}
export interface RawMessageStopEvent {
    type: 'message_stop';
}
export type RawMessageStreamEvent = RawMessageStartEvent | RawMessageDeltaEvent | RawMessageStopEvent | RawContentBlockStartEvent | RawContentBlockDeltaEvent | RawContentBlockStopEvent;
export interface RedactedThinkingBlock {
    data: string;
    type: 'redacted_thinking';
}
export interface RedactedThinkingBlockParam {
    data: string;
    type: 'redacted_thinking';
}
/**
 * Structured information about a refusal.
 */
export interface RefusalStopDetails {
    /**
     * The policy category that triggered the refusal.
     *
     * `null` when the refusal doesn't map to a named category.
     */
    category: 'cyber' | 'bio' | null;
    /**
     * Human-readable explanation of the refusal.
     *
     * This text is not guaranteed to be stable. `null` when no explanation is
     * available for the category.
     */
    explanation: string | null;
    type: 'refusal';
}
export interface SearchResultBlockParam {
    content: Array<TextBlockParam>;
    source: string;
    title: string;
    type: 'search_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    citations?: CitationsConfigParam;
}
/**
 * Tool invocation generated by a server-side tool.
 */
export interface ServerToolCaller {
    tool_id: string;
    type: 'code_execution_20250825';
}
export interface ServerToolCaller20260120 {
    tool_id: string;
    type: 'code_execution_20260120';
}
export interface ServerToolUsage {
    /**
     * The number of web fetch tool requests.
     */
    web_fetch_requests: number;
    /**
     * The number of web search tool requests.
     */
    web_search_requests: number;
}
export interface ServerToolUseBlock {
    id: string;
    /**
     * Tool invocation directly from the model.
     */
    caller: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
    input: unknown;
    name: 'web_search' | 'web_fetch' | 'code_execution' | 'bash_code_execution' | 'text_editor_code_execution' | 'tool_search_tool_regex' | 'tool_search_tool_bm25';
    type: 'server_tool_use';
}
export interface ServerToolUseBlockParam {
    id: string;
    input: unknown;
    name: 'web_search' | 'web_fetch' | 'code_execution' | 'bash_code_execution' | 'text_editor_code_execution' | 'tool_search_tool_regex' | 'tool_search_tool_bm25';
    type: 'server_tool_use';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Tool invocation directly from the model.
     */
    caller?: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
}
export interface SignatureDelta {
    signature: string;
    type: 'signature_delta';
}
export type StopReason = 'end_turn' | 'max_tokens' | 'stop_sequence' | 'tool_use' | 'pause_turn' | 'refusal';
export interface TextBlock {
    /**
     * Citations supporting the text block.
     *
     * The type of citation returned will depend on the type of document being cited.
     * Citing a PDF results in `page_location`, plain text results in `char_location`,
     * and content document results in `content_block_location`.
     */
    citations: Array<TextCitation> | null;
    text: string;
    type: 'text';
}
export interface TextBlockParam {
    text: string;
    type: 'text';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    citations?: Array<TextCitationParam> | null;
}
export type TextCitation = CitationCharLocation | CitationPageLocation | CitationContentBlockLocation | CitationsWebSearchResultLocation | CitationsSearchResultLocation;
export type TextCitationParam = CitationCharLocationParam | CitationPageLocationParam | CitationContentBlockLocationParam | CitationWebSearchResultLocationParam | CitationSearchResultLocationParam;
export interface TextDelta {
    text: string;
    type: 'text_delta';
}
export interface TextEditorCodeExecutionCreateResultBlock {
    is_file_update: boolean;
    type: 'text_editor_code_execution_create_result';
}
export interface TextEditorCodeExecutionCreateResultBlockParam {
    is_file_update: boolean;
    type: 'text_editor_code_execution_create_result';
}
export interface TextEditorCodeExecutionStrReplaceResultBlock {
    lines: Array<string> | null;
    new_lines: number | null;
    new_start: number | null;
    old_lines: number | null;
    old_start: number | null;
    type: 'text_editor_code_execution_str_replace_result';
}
export interface TextEditorCodeExecutionStrReplaceResultBlockParam {
    type: 'text_editor_code_execution_str_replace_result';
    lines?: Array<string> | null;
    new_lines?: number | null;
    new_start?: number | null;
    old_lines?: number | null;
    old_start?: number | null;
}
export interface TextEditorCodeExecutionToolResultBlock {
    content: TextEditorCodeExecutionToolResultError | TextEditorCodeExecutionViewResultBlock | TextEditorCodeExecutionCreateResultBlock | TextEditorCodeExecutionStrReplaceResultBlock;
    tool_use_id: string;
    type: 'text_editor_code_execution_tool_result';
}
export interface TextEditorCodeExecutionToolResultBlockParam {
    content: TextEditorCodeExecutionToolResultErrorParam | TextEditorCodeExecutionViewResultBlockParam | TextEditorCodeExecutionCreateResultBlockParam | TextEditorCodeExecutionStrReplaceResultBlockParam;
    tool_use_id: string;
    type: 'text_editor_code_execution_tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
export interface TextEditorCodeExecutionToolResultError {
    error_code: TextEditorCodeExecutionToolResultErrorCode;
    error_message: string | null;
    type: 'text_editor_code_execution_tool_result_error';
}
export type TextEditorCodeExecutionToolResultErrorCode = 'invalid_tool_input' | 'unavailable' | 'too_many_requests' | 'execution_time_exceeded' | 'file_not_found';
export interface TextEditorCodeExecutionToolResultErrorParam {
    error_code: TextEditorCodeExecutionToolResultErrorCode;
    type: 'text_editor_code_execution_tool_result_error';
    error_message?: string | null;
}
export interface TextEditorCodeExecutionViewResultBlock {
    content: string;
    file_type: 'text' | 'image' | 'pdf';
    num_lines: number | null;
    start_line: number | null;
    total_lines: number | null;
    type: 'text_editor_code_execution_view_result';
}
export interface TextEditorCodeExecutionViewResultBlockParam {
    content: string;
    file_type: 'text' | 'image' | 'pdf';
    type: 'text_editor_code_execution_view_result';
    num_lines?: number | null;
    start_line?: number | null;
    total_lines?: number | null;
}
export interface ThinkingBlock {
    signature: string;
    thinking: string;
    type: 'thinking';
}
export interface ThinkingBlockParam {
    signature: string;
    thinking: string;
    type: 'thinking';
}
export interface ThinkingConfigAdaptive {
    type: 'adaptive';
    /**
     * Controls how thinking content appears in the response. When set to `summarized`,
     * thinking is returned normally. When set to `omitted`, thinking content is
     * redacted but a signature is returned for multi-turn continuity. Defaults to
     * `summarized`.
     */
    display?: 'summarized' | 'omitted' | null;
}
export interface ThinkingConfigDisabled {
    type: 'disabled';
}
export interface ThinkingConfigEnabled {
    /**
     * Determines how many tokens Claude can use for its internal reasoning process.
     * Larger budgets can enable more thorough analysis for complex problems, improving
     * response quality.
     *
     * Must be ≥1024 and less than `max_tokens`.
     *
     * See
     * [extended thinking](https://docs.claude.com/en/docs/build-with-claude/extended-thinking)
     * for details.
     */
    budget_tokens: number;
    type: 'enabled';
    /**
     * Controls how thinking content appears in the response. When set to `summarized`,
     * thinking is returned normally. When set to `omitted`, thinking content is
     * redacted but a signature is returned for multi-turn continuity. Defaults to
     * `summarized`.
     */
    display?: 'summarized' | 'omitted' | null;
}
/**
 * Configuration for enabling Claude's extended thinking.
 *
 * When enabled, responses include `thinking` content blocks showing Claude's
 * thinking process before the final answer. Requires a minimum budget of 1,024
 * tokens and counts towards your `max_tokens` limit.
 *
 * See
 * [extended thinking](https://docs.claude.com/en/docs/build-with-claude/extended-thinking)
 * for details.
 */
export type ThinkingConfigParam = ThinkingConfigEnabled | ThinkingConfigDisabled | ThinkingConfigAdaptive;
export interface ThinkingDelta {
    thinking: string;
    type: 'thinking_delta';
}
export interface Tool {
    /**
     * [JSON schema](https://json-schema.org/draft/2020-12) for this tool's input.
     *
     * This defines the shape of the `input` that your tool accepts and that the model
     * will produce.
     */
    input_schema: Tool.InputSchema;
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: string;
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * Description of what this tool does.
     *
     * Tool descriptions should be as detailed as possible. The more information that
     * the model has about what the tool is and how to use it, the better it will
     * perform. You can use natural language descriptions to reinforce important
     * aspects of the tool input JSON schema.
     */
    description?: string;
    /**
     * Enable eager input streaming for this tool. When true, tool input parameters
     * will be streamed incrementally as they are generated, and types will be inferred
     * on-the-fly rather than buffering the full JSON output. When false, streaming is
     * disabled for this tool even if the fine-grained-tool-streaming beta is active.
     * When null (default), uses the default behavior based on beta headers.
     */
    eager_input_streaming?: boolean | null;
    input_examples?: Array<{
        [key: string]: unknown;
    }>;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
    type?: 'custom' | null;
}
export declare namespace Tool {
    /**
     * [JSON schema](https://json-schema.org/draft/2020-12) for this tool's input.
     *
     * This defines the shape of the `input` that your tool accepts and that the model
     * will produce.
     */
    interface InputSchema {
        type: 'object';
        properties?: unknown | null;
        required?: Array<string> | null;
        [k: string]: unknown;
    }
}
export interface ToolBash20250124 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'bash';
    type: 'bash_20250124';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    input_examples?: Array<{
        [key: string]: unknown;
    }>;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
/**
 * How the model should use the provided tools. The model can use a specific tool,
 * any available tool, decide by itself, or not use tools at all.
 */
export type ToolChoice = ToolChoiceAuto | ToolChoiceAny | ToolChoiceTool | ToolChoiceNone;
/**
 * The model will use any available tools.
 */
export interface ToolChoiceAny {
    type: 'any';
    /**
     * Whether to disable parallel tool use.
     *
     * Defaults to `false`. If set to `true`, the model will output exactly one tool
     * use.
     */
    disable_parallel_tool_use?: boolean;
}
/**
 * The model will automatically decide whether to use tools.
 */
export interface ToolChoiceAuto {
    type: 'auto';
    /**
     * Whether to disable parallel tool use.
     *
     * Defaults to `false`. If set to `true`, the model will output at most one tool
     * use.
     */
    disable_parallel_tool_use?: boolean;
}
/**
 * The model will not be allowed to use tools.
 */
export interface ToolChoiceNone {
    type: 'none';
}
/**
 * The model will use the specified tool with `tool_choice.name`.
 */
export interface ToolChoiceTool {
    /**
     * The name of the tool to use.
     */
    name: string;
    type: 'tool';
    /**
     * Whether to disable parallel tool use.
     *
     * Defaults to `false`. If set to `true`, the model will output exactly one tool
     * use.
     */
    disable_parallel_tool_use?: boolean;
}
export interface ToolReferenceBlock {
    tool_name: string;
    type: 'tool_reference';
}
/**
 * Tool reference block that can be included in tool_result content.
 */
export interface ToolReferenceBlockParam {
    tool_name: string;
    type: 'tool_reference';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
export interface ToolResultBlockParam {
    tool_use_id: string;
    type: 'tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    content?: string | Array<TextBlockParam | ImageBlockParam | SearchResultBlockParam | DocumentBlockParam | ToolReferenceBlockParam>;
    is_error?: boolean;
}
export interface ToolSearchToolBm25_20251119 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'tool_search_tool_bm25';
    type: 'tool_search_tool_bm25_20251119' | 'tool_search_tool_bm25';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface ToolSearchToolRegex20251119 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'tool_search_tool_regex';
    type: 'tool_search_tool_regex_20251119' | 'tool_search_tool_regex';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface ToolSearchToolResultBlock {
    content: ToolSearchToolResultError | ToolSearchToolSearchResultBlock;
    tool_use_id: string;
    type: 'tool_search_tool_result';
}
export interface ToolSearchToolResultBlockParam {
    content: ToolSearchToolResultErrorParam | ToolSearchToolSearchResultBlockParam;
    tool_use_id: string;
    type: 'tool_search_tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
}
export interface ToolSearchToolResultError {
    error_code: ToolSearchToolResultErrorCode;
    error_message: string | null;
    type: 'tool_search_tool_result_error';
}
export type ToolSearchToolResultErrorCode = 'invalid_tool_input' | 'unavailable' | 'too_many_requests' | 'execution_time_exceeded';
export interface ToolSearchToolResultErrorParam {
    error_code: ToolSearchToolResultErrorCode;
    type: 'tool_search_tool_result_error';
}
export interface ToolSearchToolSearchResultBlock {
    tool_references: Array<ToolReferenceBlock>;
    type: 'tool_search_tool_search_result';
}
export interface ToolSearchToolSearchResultBlockParam {
    tool_references: Array<ToolReferenceBlockParam>;
    type: 'tool_search_tool_search_result';
}
export interface ToolTextEditor20250124 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'str_replace_editor';
    type: 'text_editor_20250124';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    input_examples?: Array<{
        [key: string]: unknown;
    }>;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface ToolTextEditor20250429 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'str_replace_based_edit_tool';
    type: 'text_editor_20250429';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    input_examples?: Array<{
        [key: string]: unknown;
    }>;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface ToolTextEditor20250728 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'str_replace_based_edit_tool';
    type: 'text_editor_20250728';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    input_examples?: Array<{
        [key: string]: unknown;
    }>;
    /**
     * Maximum number of characters to display when viewing a file. If not specified,
     * defaults to displaying the full file.
     */
    max_characters?: number | null;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
/**
 * Code execution tool with REPL state persistence (daemon mode + gVisor
 * checkpoint).
 */
export type ToolUnion = Tool | ToolBash20250124 | CodeExecutionTool20250522 | CodeExecutionTool20250825 | CodeExecutionTool20260120 | MemoryTool20250818 | ToolTextEditor20250124 | ToolTextEditor20250429 | ToolTextEditor20250728 | WebSearchTool20250305 | WebFetchTool20250910 | WebSearchTool20260209 | WebFetchTool20260209 | WebFetchTool20260309 | ToolSearchToolBm25_20251119 | ToolSearchToolRegex20251119;
export interface ToolUseBlock {
    id: string;
    /**
     * Tool invocation directly from the model.
     */
    caller: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
    input: unknown;
    name: string;
    type: 'tool_use';
}
export interface ToolUseBlockParam {
    id: string;
    input: unknown;
    name: string;
    type: 'tool_use';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Tool invocation directly from the model.
     */
    caller?: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
}
export interface URLImageSource {
    type: 'url';
    url: string;
}
export interface URLPDFSource {
    type: 'url';
    url: string;
}
export interface Usage {
    /**
     * Breakdown of cached tokens by TTL
     */
    cache_creation: CacheCreation | null;
    /**
     * The number of input tokens used to create the cache entry.
     */
    cache_creation_input_tokens: number | null;
    /**
     * The number of input tokens read from the cache.
     */
    cache_read_input_tokens: number | null;
    /**
     * The geographic region where inference was performed for this request.
     */
    inference_geo: string | null;
    /**
     * The number of input tokens which were used.
     */
    input_tokens: number;
    /**
     * The number of output tokens which were used.
     */
    output_tokens: number;
    /**
     * The number of server tool requests.
     */
    server_tool_use: ServerToolUsage | null;
    /**
     * If the request used the priority, standard, or batch tier.
     */
    service_tier: 'standard' | 'priority' | 'batch' | null;
}
export interface UserLocation {
    type: 'approximate';
    /**
     * The city of the user.
     */
    city?: string | null;
    /**
     * The two letter
     * [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2) of the
     * user.
     */
    country?: string | null;
    /**
     * The region of the user.
     */
    region?: string | null;
    /**
     * The [IANA timezone](https://nodatime.org/TimeZones) of the user.
     */
    timezone?: string | null;
}
export interface WebFetchBlock {
    content: DocumentBlock;
    /**
     * ISO 8601 timestamp when the content was retrieved
     */
    retrieved_at: string | null;
    type: 'web_fetch_result';
    /**
     * Fetched content URL
     */
    url: string;
}
export interface WebFetchBlockParam {
    content: DocumentBlockParam;
    type: 'web_fetch_result';
    /**
     * Fetched content URL
     */
    url: string;
    /**
     * ISO 8601 timestamp when the content was retrieved
     */
    retrieved_at?: string | null;
}
export interface WebFetchTool20250910 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'web_fetch';
    type: 'web_fetch_20250910';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * List of domains to allow fetching from
     */
    allowed_domains?: Array<string> | null;
    /**
     * List of domains to block fetching from
     */
    blocked_domains?: Array<string> | null;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Citations configuration for fetched documents. Citations are disabled by
     * default.
     */
    citations?: CitationsConfigParam | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * Maximum number of tokens used by including web page text content in the context.
     * The limit is approximate and does not apply to binary content such as PDFs.
     */
    max_content_tokens?: number | null;
    /**
     * Maximum number of times the tool can be used in the API request.
     */
    max_uses?: number | null;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
export interface WebFetchTool20260209 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'web_fetch';
    type: 'web_fetch_20260209';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * List of domains to allow fetching from
     */
    allowed_domains?: Array<string> | null;
    /**
     * List of domains to block fetching from
     */
    blocked_domains?: Array<string> | null;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Citations configuration for fetched documents. Citations are disabled by
     * default.
     */
    citations?: CitationsConfigParam | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * Maximum number of tokens used by including web page text content in the context.
     * The limit is approximate and does not apply to binary content such as PDFs.
     */
    max_content_tokens?: number | null;
    /**
     * Maximum number of times the tool can be used in the API request.
     */
    max_uses?: number | null;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
}
/**
 * Web fetch tool with use_cache parameter for bypassing cached content.
 */
export interface WebFetchTool20260309 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'web_fetch';
    type: 'web_fetch_20260309';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * List of domains to allow fetching from
     */
    allowed_domains?: Array<string> | null;
    /**
     * List of domains to block fetching from
     */
    blocked_domains?: Array<string> | null;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Citations configuration for fetched documents. Citations are disabled by
     * default.
     */
    citations?: CitationsConfigParam | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * Maximum number of tokens used by including web page text content in the context.
     * The limit is approximate and does not apply to binary content such as PDFs.
     */
    max_content_tokens?: number | null;
    /**
     * Maximum number of times the tool can be used in the API request.
     */
    max_uses?: number | null;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
    /**
     * Whether to use cached content. Set to false to bypass the cache and fetch fresh
     * content. Only set to false when the user explicitly requests fresh content or
     * when fetching rapidly-changing sources.
     */
    use_cache?: boolean;
}
export interface WebFetchToolResultBlock {
    /**
     * Tool invocation directly from the model.
     */
    caller: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
    content: WebFetchToolResultErrorBlock | WebFetchBlock;
    tool_use_id: string;
    type: 'web_fetch_tool_result';
}
export interface WebFetchToolResultBlockParam {
    content: WebFetchToolResultErrorBlockParam | WebFetchBlockParam;
    tool_use_id: string;
    type: 'web_fetch_tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Tool invocation directly from the model.
     */
    caller?: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
}
export interface WebFetchToolResultErrorBlock {
    error_code: WebFetchToolResultErrorCode;
    type: 'web_fetch_tool_result_error';
}
export interface WebFetchToolResultErrorBlockParam {
    error_code: WebFetchToolResultErrorCode;
    type: 'web_fetch_tool_result_error';
}
export type WebFetchToolResultErrorCode = 'invalid_tool_input' | 'url_too_long' | 'url_not_allowed' | 'url_not_accessible' | 'unsupported_content_type' | 'too_many_requests' | 'max_uses_exceeded' | 'unavailable';
export interface WebSearchResultBlock {
    encrypted_content: string;
    page_age: string | null;
    title: string;
    type: 'web_search_result';
    url: string;
}
export interface WebSearchResultBlockParam {
    encrypted_content: string;
    title: string;
    type: 'web_search_result';
    url: string;
    page_age?: string | null;
}
export interface WebSearchTool20250305 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'web_search';
    type: 'web_search_20250305';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * If provided, only these domains will be included in results. Cannot be used
     * alongside `blocked_domains`.
     */
    allowed_domains?: Array<string> | null;
    /**
     * If provided, these domains will never appear in results. Cannot be used
     * alongside `allowed_domains`.
     */
    blocked_domains?: Array<string> | null;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * Maximum number of times the tool can be used in the API request.
     */
    max_uses?: number | null;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
    /**
     * Parameters for the user's location. Used to provide more relevant search
     * results.
     */
    user_location?: UserLocation | null;
}
export declare namespace WebSearchTool20250305 {
    /**
     * @deprecated Import `UserLocation` from `anthropic` directly instead of using
     *   `WebSearchTool20250305.UserLocation`.
     */
    type UserLocation = Messages.UserLocation;
}
export interface WebSearchTool20260209 {
    /**
     * Name of the tool.
     *
     * This is how the tool will be called by the model and in `tool_use` blocks.
     */
    name: 'web_search';
    type: 'web_search_20260209';
    allowed_callers?: Array<'direct' | 'code_execution_20250825' | 'code_execution_20260120'>;
    /**
     * If provided, only these domains will be included in results. Cannot be used
     * alongside `blocked_domains`.
     */
    allowed_domains?: Array<string> | null;
    /**
     * If provided, these domains will never appear in results. Cannot be used
     * alongside `allowed_domains`.
     */
    blocked_domains?: Array<string> | null;
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * If true, tool will not be included in initial system prompt. Only loaded when
     * returned via tool_reference from tool search.
     */
    defer_loading?: boolean;
    /**
     * Maximum number of times the tool can be used in the API request.
     */
    max_uses?: number | null;
    /**
     * When true, guarantees schema validation on tool names and inputs
     */
    strict?: boolean;
    /**
     * Parameters for the user's location. Used to provide more relevant search
     * results.
     */
    user_location?: UserLocation | null;
}
export declare namespace WebSearchTool20260209 {
    /**
     * @deprecated Import `UserLocation` from `anthropic` directly instead of using
     *   `WebSearchTool20260209.UserLocation`.
     */
    type UserLocation = Messages.UserLocation;
}
export interface WebSearchToolRequestError {
    error_code: WebSearchToolResultErrorCode;
    type: 'web_search_tool_result_error';
}
export interface WebSearchToolResultBlock {
    /**
     * Tool invocation directly from the model.
     */
    caller: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
    content: WebSearchToolResultBlockContent;
    tool_use_id: string;
    type: 'web_search_tool_result';
}
export type WebSearchToolResultBlockContent = WebSearchToolResultError | Array<WebSearchResultBlock>;
export interface WebSearchToolResultBlockParam {
    content: WebSearchToolResultBlockParamContent;
    tool_use_id: string;
    type: 'web_search_tool_result';
    /**
     * Create a cache control breakpoint at this content block.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Tool invocation directly from the model.
     */
    caller?: DirectCaller | ServerToolCaller | ServerToolCaller20260120;
}
export type WebSearchToolResultBlockParamContent = Array<WebSearchResultBlockParam> | WebSearchToolRequestError;
export interface WebSearchToolResultError {
    error_code: WebSearchToolResultErrorCode;
    type: 'web_search_tool_result_error';
}
export type WebSearchToolResultErrorCode = 'invalid_tool_input' | 'unavailable' | 'max_uses_exceeded' | 'too_many_requests' | 'query_too_long' | 'request_too_large';
export type MessageStreamEvent = RawMessageStreamEvent;
export type MessageStartEvent = RawMessageStartEvent;
export type MessageDeltaEvent = RawMessageDeltaEvent;
export type MessageStopEvent = RawMessageStopEvent;
export type ContentBlockStartEvent = RawContentBlockStartEvent;
export type ContentBlockDeltaEvent = RawContentBlockDeltaEvent;
export type ContentBlockStopEvent = RawContentBlockStopEvent;
export type MessageCreateParams = MessageCreateParamsNonStreaming | MessageCreateParamsStreaming;
export interface MessageCreateParamsBase {
    /**
     * The maximum number of tokens to generate before stopping.
     *
     * Note that our models may stop _before_ reaching this maximum. This parameter
     * only specifies the absolute maximum number of tokens to generate.
     *
     * Different models have different maximum values for this parameter. See
     * [models](https://docs.claude.com/en/docs/models-overview) for details.
     */
    max_tokens: number;
    /**
     * Input messages.
     *
     * Our models are trained to operate on alternating `user` and `assistant`
     * conversational turns. When creating a new `Message`, you specify the prior
     * conversational turns with the `messages` parameter, and the model then generates
     * the next `Message` in the conversation. Consecutive `user` or `assistant` turns
     * in your request will be combined into a single turn.
     *
     * Each input message must be an object with a `role` and `content`. You can
     * specify a single `user`-role message, or you can include multiple `user` and
     * `assistant` messages.
     *
     * If the final message uses the `assistant` role, the response content will
     * continue immediately from the content in that message. This can be used to
     * constrain part of the model's response.
     *
     * Example with a single `user` message:
     *
     * ```json
     * [{ "role": "user", "content": "Hello, Claude" }]
     * ```
     *
     * Example with multiple conversational turns:
     *
     * ```json
     * [
     *   { "role": "user", "content": "Hello there." },
     *   { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
     *   { "role": "user", "content": "Can you explain LLMs in plain English?" }
     * ]
     * ```
     *
     * Example with a partially-filled response from Claude:
     *
     * ```json
     * [
     *   {
     *     "role": "user",
     *     "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
     *   },
     *   { "role": "assistant", "content": "The best answer is (" }
     * ]
     * ```
     *
     * Each input message `content` may be either a single `string` or an array of
     * content blocks, where each block has a specific `type`. Using a `string` for
     * `content` is shorthand for an array of one content block of type `"text"`. The
     * following input messages are equivalent:
     *
     * ```json
     * { "role": "user", "content": "Hello, Claude" }
     * ```
     *
     * ```json
     * { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
     * ```
     *
     * See [input examples](https://docs.claude.com/en/api/messages-examples).
     *
     * Note that if you want to include a
     * [system prompt](https://docs.claude.com/en/docs/system-prompts), you can use the
     * top-level `system` parameter — there is no `"system"` role for input messages in
     * the Messages API.
     *
     * There is a limit of 100,000 messages in a single request.
     */
    messages: Array<MessageParam>;
    /**
     * The model that will complete your prompt.\n\nSee
     * [models](https://docs.anthropic.com/en/docs/models-overview) for additional
     * details and options.
     */
    model: Model;
    /**
     * Top-level cache control automatically applies a cache_control marker to the last
     * cacheable block in the request.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Container identifier for reuse across requests.
     */
    container?: string | null;
    /**
     * Specifies the geographic region for inference processing. If not specified, the
     * workspace's `default_inference_geo` is used.
     */
    inference_geo?: string | null;
    /**
     * An object describing metadata about the request.
     */
    metadata?: Metadata;
    /**
     * Configuration options for the model's output, such as the output format.
     */
    output_config?: OutputConfig;
    /**
     * Determines whether to use priority capacity (if available) or standard capacity
     * for this request.
     *
     * Anthropic offers different levels of service for your API requests. See
     * [service-tiers](https://docs.claude.com/en/api/service-tiers) for details.
     */
    service_tier?: 'auto' | 'standard_only';
    /**
     * Custom text sequences that will cause the model to stop generating.
     *
     * Our models will normally stop when they have naturally completed their turn,
     * which will result in a response `stop_reason` of `"end_turn"`.
     *
     * If you want the model to stop generating when it encounters custom strings of
     * text, you can use the `stop_sequences` parameter. If the model encounters one of
     * the custom sequences, the response `stop_reason` value will be `"stop_sequence"`
     * and the response `stop_sequence` value will contain the matched stop sequence.
     */
    stop_sequences?: Array<string>;
    /**
     * Whether to incrementally stream the response using server-sent events.
     *
     * See [streaming](https://docs.claude.com/en/api/messages-streaming) for details.
     */
    stream?: boolean;
    /**
     * System prompt.
     *
     * A system prompt is a way of providing context and instructions to Claude, such
     * as specifying a particular goal or role. See our
     * [guide to system prompts](https://docs.claude.com/en/docs/system-prompts).
     */
    system?: string | Array<TextBlockParam>;
    /**
     * @deprecated Deprecated. Models released after Claude Opus 4.6 do not support
     * setting temperature. A value of 1.0 of will be accepted for backwards
     * compatibility, all other values will be rejected with a 400 error.
     */
    temperature?: number;
    /**
     * Configuration for enabling Claude's extended thinking.
     *
     * When enabled, responses include `thinking` content blocks showing Claude's
     * thinking process before the final answer. Requires a minimum budget of 1,024
     * tokens and counts towards your `max_tokens` limit.
     *
     * See
     * [extended thinking](https://docs.claude.com/en/docs/build-with-claude/extended-thinking)
     * for details.
     */
    thinking?: ThinkingConfigParam;
    /**
     * How the model should use the provided tools. The model can use a specific tool,
     * any available tool, decide by itself, or not use tools at all.
     */
    tool_choice?: ToolChoice;
    /**
     * Definitions of tools that the model may use.
     *
     * If you include `tools` in your API request, the model may return `tool_use`
     * content blocks that represent the model's use of those tools. You can then run
     * those tools using the tool input generated by the model and then optionally
     * return results back to the model using `tool_result` content blocks.
     *
     * There are two types of tools: **client tools** and **server tools**. The
     * behavior described below applies to client tools. For
     * [server tools](https://docs.claude.com/en/docs/agents-and-tools/tool-use/overview#server-tools),
     * see their individual documentation as each has its own behavior (e.g., the
     * [web search tool](https://docs.claude.com/en/docs/agents-and-tools/tool-use/web-search-tool)).
     *
     * Each tool definition includes:
     *
     * - `name`: Name of the tool.
     * - `description`: Optional, but strongly-recommended description of the tool.
     * - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
     *   tool `input` shape that the model will produce in `tool_use` output content
     *   blocks.
     *
     * For example, if you defined `tools` as:
     *
     * ```json
     * [
     *   {
     *     "name": "get_stock_price",
     *     "description": "Get the current stock price for a given ticker symbol.",
     *     "input_schema": {
     *       "type": "object",
     *       "properties": {
     *         "ticker": {
     *           "type": "string",
     *           "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
     *         }
     *       },
     *       "required": ["ticker"]
     *     }
     *   }
     * ]
     * ```
     *
     * And then asked the model "What's the S&P 500 at today?", the model might produce
     * `tool_use` content blocks in the response like this:
     *
     * ```json
     * [
     *   {
     *     "type": "tool_use",
     *     "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
     *     "name": "get_stock_price",
     *     "input": { "ticker": "^GSPC" }
     *   }
     * ]
     * ```
     *
     * You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
     * input, and return the following back to the model in a subsequent `user`
     * message:
     *
     * ```json
     * [
     *   {
     *     "type": "tool_result",
     *     "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
     *     "content": "259.75 USD"
     *   }
     * ]
     * ```
     *
     * Tools can be used for workflows that include running client-side tools and
     * functions, or more generally whenever you want the model to produce a particular
     * JSON structure of output.
     *
     * See our [guide](https://docs.claude.com/en/docs/tool-use) for more details.
     */
    tools?: Array<ToolUnion>;
    /**
     * @deprecated Deprecated. Models released after Claude Opus 4.6 do not accept
     * top_k; any value will be rejected with a 400 error.
     */
    top_k?: number;
    /**
     * @deprecated Deprecated. Models released after Claude Opus 4.6 do not support
     * setting top_p. A value >= 0.99 will be accepted for backwards compatibility, all
     * other values will be rejected with a 400 error.
     */
    top_p?: number;
}
export declare namespace MessageCreateParams {
    type MessageCreateParamsNonStreaming = MessagesAPI.MessageCreateParamsNonStreaming;
    type MessageCreateParamsStreaming = MessagesAPI.MessageCreateParamsStreaming;
}
export interface MessageCreateParamsNonStreaming extends MessageCreateParamsBase {
    /**
     * Whether to incrementally stream the response using server-sent events.
     *
     * See [streaming](https://docs.claude.com/en/api/messages-streaming) for details.
     */
    stream?: false;
}
export interface MessageCreateParamsStreaming extends MessageCreateParamsBase {
    /**
     * Whether to incrementally stream the response using server-sent events.
     *
     * See [streaming](https://docs.claude.com/en/api/messages-streaming) for details.
     */
    stream: true;
}
export type MessageStreamParams = ParseableMessageCreateParams;
export interface MessageCountTokensParams {
    /**
     * Input messages.
     *
     * Our models are trained to operate on alternating `user` and `assistant`
     * conversational turns. When creating a new `Message`, you specify the prior
     * conversational turns with the `messages` parameter, and the model then generates
     * the next `Message` in the conversation. Consecutive `user` or `assistant` turns
     * in your request will be combined into a single turn.
     *
     * Each input message must be an object with a `role` and `content`. You can
     * specify a single `user`-role message, or you can include multiple `user` and
     * `assistant` messages.
     *
     * If the final message uses the `assistant` role, the response content will
     * continue immediately from the content in that message. This can be used to
     * constrain part of the model's response.
     *
     * Example with a single `user` message:
     *
     * ```json
     * [{ "role": "user", "content": "Hello, Claude" }]
     * ```
     *
     * Example with multiple conversational turns:
     *
     * ```json
     * [
     *   { "role": "user", "content": "Hello there." },
     *   { "role": "assistant", "content": "Hi, I'm Claude. How can I help you?" },
     *   { "role": "user", "content": "Can you explain LLMs in plain English?" }
     * ]
     * ```
     *
     * Example with a partially-filled response from Claude:
     *
     * ```json
     * [
     *   {
     *     "role": "user",
     *     "content": "What's the Greek name for Sun? (A) Sol (B) Helios (C) Sun"
     *   },
     *   { "role": "assistant", "content": "The best answer is (" }
     * ]
     * ```
     *
     * Each input message `content` may be either a single `string` or an array of
     * content blocks, where each block has a specific `type`. Using a `string` for
     * `content` is shorthand for an array of one content block of type `"text"`. The
     * following input messages are equivalent:
     *
     * ```json
     * { "role": "user", "content": "Hello, Claude" }
     * ```
     *
     * ```json
     * { "role": "user", "content": [{ "type": "text", "text": "Hello, Claude" }] }
     * ```
     *
     * See [input examples](https://docs.claude.com/en/api/messages-examples).
     *
     * Note that if you want to include a
     * [system prompt](https://docs.claude.com/en/docs/system-prompts), you can use the
     * top-level `system` parameter — there is no `"system"` role for input messages in
     * the Messages API.
     *
     * There is a limit of 100,000 messages in a single request.
     */
    messages: Array<MessageParam>;
    /**
     * The model that will complete your prompt.\n\nSee
     * [models](https://docs.anthropic.com/en/docs/models-overview) for additional
     * details and options.
     */
    model: Model;
    /**
     * Top-level cache control automatically applies a cache_control marker to the last
     * cacheable block in the request.
     */
    cache_control?: CacheControlEphemeral | null;
    /**
     * Configuration options for the model's output, such as the output format.
     */
    output_config?: OutputConfig;
    /**
     * System prompt.
     *
     * A system prompt is a way of providing context and instructions to Claude, such
     * as specifying a particular goal or role. See our
     * [guide to system prompts](https://docs.claude.com/en/docs/system-prompts).
     */
    system?: string | Array<TextBlockParam>;
    /**
     * Configuration for enabling Claude's extended thinking.
     *
     * When enabled, responses include `thinking` content blocks showing Claude's
     * thinking process before the final answer. Requires a minimum budget of 1,024
     * tokens and counts towards your `max_tokens` limit.
     *
     * See
     * [extended thinking](https://docs.claude.com/en/docs/build-with-claude/extended-thinking)
     * for details.
     */
    thinking?: ThinkingConfigParam;
    /**
     * How the model should use the provided tools. The model can use a specific tool,
     * any available tool, decide by itself, or not use tools at all.
     */
    tool_choice?: ToolChoice;
    /**
     * Definitions of tools that the model may use.
     *
     * If you include `tools` in your API request, the model may return `tool_use`
     * content blocks that represent the model's use of those tools. You can then run
     * those tools using the tool input generated by the model and then optionally
     * return results back to the model using `tool_result` content blocks.
     *
     * There are two types of tools: **client tools** and **server tools**. The
     * behavior described below applies to client tools. For
     * [server tools](https://docs.claude.com/en/docs/agents-and-tools/tool-use/overview#server-tools),
     * see their individual documentation as each has its own behavior (e.g., the
     * [web search tool](https://docs.claude.com/en/docs/agents-and-tools/tool-use/web-search-tool)).
     *
     * Each tool definition includes:
     *
     * - `name`: Name of the tool.
     * - `description`: Optional, but strongly-recommended description of the tool.
     * - `input_schema`: [JSON schema](https://json-schema.org/draft/2020-12) for the
     *   tool `input` shape that the model will produce in `tool_use` output content
     *   blocks.
     *
     * For example, if you defined `tools` as:
     *
     * ```json
     * [
     *   {
     *     "name": "get_stock_price",
     *     "description": "Get the current stock price for a given ticker symbol.",
     *     "input_schema": {
     *       "type": "object",
     *       "properties": {
     *         "ticker": {
     *           "type": "string",
     *           "description": "The stock ticker symbol, e.g. AAPL for Apple Inc."
     *         }
     *       },
     *       "required": ["ticker"]
     *     }
     *   }
     * ]
     * ```
     *
     * And then asked the model "What's the S&P 500 at today?", the model might produce
     * `tool_use` content blocks in the response like this:
     *
     * ```json
     * [
     *   {
     *     "type": "tool_use",
     *     "id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
     *     "name": "get_stock_price",
     *     "input": { "ticker": "^GSPC" }
     *   }
     * ]
     * ```
     *
     * You might then run your `get_stock_price` tool with `{"ticker": "^GSPC"}` as an
     * input, and return the following back to the model in a subsequent `user`
     * message:
     *
     * ```json
     * [
     *   {
     *     "type": "tool_result",
     *     "tool_use_id": "toolu_01D7FLrfh4GYq7yT1ULFeyMV",
     *     "content": "259.75 USD"
     *   }
     * ]
     * ```
     *
     * Tools can be used for workflows that include running client-side tools and
     * functions, or more generally whenever you want the model to produce a particular
     * JSON structure of output.
     *
     * See our [guide](https://docs.claude.com/en/docs/tool-use) for more details.
     */
    tools?: Array<MessageCountTokensTool>;
}
export declare namespace Messages {
    export { type Base64ImageSource as Base64ImageSource, type Base64PDFSource as Base64PDFSource, type BashCodeExecutionOutputBlock as BashCodeExecutionOutputBlock, type BashCodeExecutionOutputBlockParam as BashCodeExecutionOutputBlockParam, type BashCodeExecutionResultBlock as BashCodeExecutionResultBlock, type BashCodeExecutionResultBlockParam as BashCodeExecutionResultBlockParam, type BashCodeExecutionToolResultBlock as BashCodeExecutionToolResultBlock, type BashCodeExecutionToolResultBlockParam as BashCodeExecutionToolResultBlockParam, type BashCodeExecutionToolResultError as BashCodeExecutionToolResultError, type BashCodeExecutionToolResultErrorCode as BashCodeExecutionToolResultErrorCode, type BashCodeExecutionToolResultErrorParam as BashCodeExecutionToolResultErrorParam, type CacheControlEphemeral as CacheControlEphemeral, type CacheCreation as CacheCreation, type CitationCharLocation as CitationCharLocation, type CitationCharLocationParam as CitationCharLocationParam, type CitationContentBlockLocation as CitationContentBlockLocation, type CitationContentBlockLocationParam as CitationContentBlockLocationParam, type CitationPageLocation as CitationPageLocation, type CitationPageLocationParam as CitationPageLocationParam, type CitationSearchResultLocationParam as CitationSearchResultLocationParam, type CitationWebSearchResultLocationParam as CitationWebSearchResultLocationParam, type CitationsConfig as CitationsConfig, type CitationsConfigParam as CitationsConfigParam, type CitationsDelta as CitationsDelta, type CitationsSearchResultLocation as CitationsSearchResultLocation, type CitationsWebSearchResultLocation as CitationsWebSearchResultLocation, type CodeExecutionOutputBlock as CodeExecutionOutputBlock, type CodeExecutionOutputBlockParam as CodeExecutionOutputBlockParam, type CodeExecutionResultBlock as CodeExecutionResultBlock, type CodeExecutionResultBlockParam as CodeExecutionResultBlockParam, type CodeExecutionTool20250522 as CodeExecutionTool20250522, type CodeExecutionTool20250825 as CodeExecutionTool20250825, type CodeExecutionTool20260120 as CodeExecutionTool20260120, type CodeExecutionToolResultBlock as CodeExecutionToolResultBlock, type CodeExecutionToolResultBlockContent as CodeExecutionToolResultBlockContent, type CodeExecutionToolResultBlockParam as CodeExecutionToolResultBlockParam, type CodeExecutionToolResultBlockParamContent as CodeExecutionToolResultBlockParamContent, type CodeExecutionToolResultError as CodeExecutionToolResultError, type CodeExecutionToolResultErrorCode as CodeExecutionToolResultErrorCode, type CodeExecutionToolResultErrorParam as CodeExecutionToolResultErrorParam, type Container as Container, type ContainerUploadBlock as ContainerUploadBlock, type ContainerUploadBlockParam as ContainerUploadBlockParam, type ContentBlock as ContentBlock, type ContentBlockParam as ContentBlockParam, type ContentBlockStartEvent as ContentBlockStartEvent, type ContentBlockStopEvent as ContentBlockStopEvent, type ContentBlockSource as ContentBlockSource, type ContentBlockSourceContent as ContentBlockSourceContent, type DirectCaller as DirectCaller, type DocumentBlock as DocumentBlock, type DocumentBlockParam as DocumentBlockParam, type EncryptedCodeExecutionResultBlock as EncryptedCodeExecutionResultBlock, type EncryptedCodeExecutionResultBlockParam as EncryptedCodeExecutionResultBlockParam, type ImageBlockParam as ImageBlockParam, type InputJSONDelta as InputJSONDelta, type JSONOutputFormat as JSONOutputFormat, type MemoryTool20250818 as MemoryTool20250818, type Message as Message, type MessageCountTokensTool as MessageCountTokensTool, type MessageDeltaEvent as MessageDeltaEvent, type MessageDeltaUsage as MessageDeltaUsage, type MessageParam as MessageParam, type MessageTokensCount as MessageTokensCount, type Metadata as Metadata, type Model as Model, type OutputConfig as OutputConfig, type PlainTextSource as PlainTextSource, type RawContentBlockDelta as RawContentBlockDelta, type RawContentBlockDeltaEvent as RawContentBlockDeltaEvent, type RawContentBlockStartEvent as RawContentBlockStartEvent, type RawContentBlockStopEvent as RawContentBlockStopEvent, type RawMessageDeltaEvent as RawMessageDeltaEvent, type RawMessageStartEvent as RawMessageStartEvent, type RawMessageStopEvent as RawMessageStopEvent, type RawMessageStreamEvent as RawMessageStreamEvent, type RedactedThinkingBlock as RedactedThinkingBlock, type RedactedThinkingBlockParam as RedactedThinkingBlockParam, type RefusalStopDetails as RefusalStopDetails, type SearchResultBlockParam as SearchResultBlockParam, type ServerToolCaller as ServerToolCaller, type ServerToolCaller20260120 as ServerToolCaller20260120, type ServerToolUsage as ServerToolUsage, type ServerToolUseBlock as ServerToolUseBlock, type ServerToolUseBlockParam as ServerToolUseBlockParam, type SignatureDelta as SignatureDelta, type StopReason as StopReason, type TextBlock as TextBlock, type TextBlockParam as TextBlockParam, type TextCitation as TextCitation, type TextCitationParam as TextCitationParam, type TextDelta as TextDelta, type TextEditorCodeExecutionCreateResultBlock as TextEditorCodeExecutionCreateResultBlock, type TextEditorCodeExecutionCreateResultBlockParam as TextEditorCodeExecutionCreateResultBlockParam, type TextEditorCodeExecutionStrReplaceResultBlock as TextEditorCodeExecutionStrReplaceResultBlock, type TextEditorCodeExecutionStrReplaceResultBlockParam as TextEditorCodeExecutionStrReplaceResultBlockParam, type TextEditorCodeExecutionToolResultBlock as TextEditorCodeExecutionToolResultBlock, type TextEditorCodeExecutionToolResultBlockParam as TextEditorCodeExecutionToolResultBlockParam, type TextEditorCodeExecutionToolResultError as TextEditorCodeExecutionToolResultError, type TextEditorCodeExecutionToolResultErrorCode as TextEditorCodeExecutionToolResultErrorCode, type TextEditorCodeExecutionToolResultErrorParam as TextEditorCodeExecutionToolResultErrorParam, type TextEditorCodeExecutionViewResultBlock as TextEditorCodeExecutionViewResultBlock, type TextEditorCodeExecutionViewResultBlockParam as TextEditorCodeExecutionViewResultBlockParam, type ThinkingBlock as ThinkingBlock, type ThinkingBlockParam as ThinkingBlockParam, type ThinkingConfigAdaptive as ThinkingConfigAdaptive, type ThinkingConfigDisabled as ThinkingConfigDisabled, type ThinkingConfigEnabled as ThinkingConfigEnabled, type ThinkingConfigParam as ThinkingConfigParam, type ThinkingDelta as ThinkingDelta, type Tool as Tool, type ToolBash20250124 as ToolBash20250124, type ToolChoice as ToolChoice, type ToolChoiceAny as ToolChoiceAny, type ToolChoiceAuto as ToolChoiceAuto, type ToolChoiceNone as ToolChoiceNone, type ToolChoiceTool as ToolChoiceTool, type ToolReferenceBlock as ToolReferenceBlock, type ToolReferenceBlockParam as ToolReferenceBlockParam, type ToolResultBlockParam as ToolResultBlockParam, type ToolSearchToolBm25_20251119 as ToolSearchToolBm25_20251119, type ToolSearchToolRegex20251119 as ToolSearchToolRegex20251119, type ToolSearchToolResultBlock as ToolSearchToolResultBlock, type ToolSearchToolResultBlockParam as ToolSearchToolResultBlockParam, type ToolSearchToolResultError as ToolSearchToolResultError, type ToolSearchToolResultErrorCode as ToolSearchToolResultErrorCode, type ToolSearchToolResultErrorParam as ToolSearchToolResultErrorParam, type ToolSearchToolSearchResultBlock as ToolSearchToolSearchResultBlock, type ToolSearchToolSearchResultBlockParam as ToolSearchToolSearchResultBlockParam, type ToolTextEditor20250124 as ToolTextEditor20250124, type ToolTextEditor20250429 as ToolTextEditor20250429, type ToolTextEditor20250728 as ToolTextEditor20250728, type ToolUnion as ToolUnion, type ToolUseBlock as ToolUseBlock, type ToolUseBlockParam as ToolUseBlockParam, type URLImageSource as URLImageSource, type URLPDFSource as URLPDFSource, type Usage as Usage, type UserLocation as UserLocation, type WebFetchBlock as WebFetchBlock, type WebFetchBlockParam as WebFetchBlockParam, type WebFetchTool20250910 as WebFetchTool20250910, type WebFetchTool20260209 as WebFetchTool20260209, type WebFetchTool20260309 as WebFetchTool20260309, type WebFetchToolResultBlock as WebFetchToolResultBlock, type WebFetchToolResultBlockParam as WebFetchToolResultBlockParam, type WebFetchToolResultErrorBlock as WebFetchToolResultErrorBlock, type WebFetchToolResultErrorBlockParam as WebFetchToolResultErrorBlockParam, type WebFetchToolResultErrorCode as WebFetchToolResultErrorCode, type WebSearchResultBlock as WebSearchResultBlock, type WebSearchResultBlockParam as WebSearchResultBlockParam, type WebSearchTool20250305 as WebSearchTool20250305, type WebSearchTool20260209 as WebSearchTool20260209, type WebSearchToolRequestError as WebSearchToolRequestError, type WebSearchToolResultBlock as WebSearchToolResultBlock, type WebSearchToolResultBlockContent as WebSearchToolResultBlockContent, type WebSearchToolResultBlockParam as WebSearchToolResultBlockParam, type WebSearchToolResultBlockParamContent as WebSearchToolResultBlockParamContent, type WebSearchToolResultError as WebSearchToolResultError, type MessageStreamEvent as MessageStreamEvent, type MessageStartEvent as MessageStartEvent, type MessageStopEvent as MessageStopEvent, type ContentBlockDeltaEvent as ContentBlockDeltaEvent, type MessageCreateParams as MessageCreateParams, type MessageCreateParamsNonStreaming as MessageCreateParamsNonStreaming, type MessageCreateParamsStreaming as MessageCreateParamsStreaming, type MessageStreamParams as MessageStreamParams, type MessageCountTokensParams as MessageCountTokensParams, };
    export { Batches as Batches, type DeletedMessageBatch as DeletedMessageBatch, type MessageBatch as MessageBatch, type MessageBatchCanceledResult as MessageBatchCanceledResult, type MessageBatchErroredResult as MessageBatchErroredResult, type MessageBatchExpiredResult as MessageBatchExpiredResult, type MessageBatchIndividualResponse as MessageBatchIndividualResponse, type MessageBatchRequestCounts as MessageBatchRequestCounts, type MessageBatchResult as MessageBatchResult, type MessageBatchSucceededResult as MessageBatchSucceededResult, type MessageBatchesPage as MessageBatchesPage, type BatchCreateParams as BatchCreateParams, type BatchListParams as BatchListParams, };
}
//# sourceMappingURL=messages.d.ts.map